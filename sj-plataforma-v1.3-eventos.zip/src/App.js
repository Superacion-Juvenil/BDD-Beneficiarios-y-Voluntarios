import React, { useState, useEffect } from "react";
import "./index.css";
import { hashPassword, parseCURP, calcAge, isMinor } from "./crypto";
import { loadAuth, saveAuth, loadUsers, saveUsers } from "./storage";
import { LOGO_SRC, SEED_USERS } from "./seedData";
import { EVALUACIONES, evaluacionesParaUsuario, CATEGORIAS } from "./evaluaciones";
import { EVENT_TYPES, getEventTypeInfo, eventDisplayName, newEventId, formatEventDate } from "./eventos";

/* ─── constants ─────────────────────────────────────────────── */
const SJB  = "#1A56A4";
const SJBG = "#e8f0fb";
const SJBD = "#123d7a";
const DEFAULT_PASS = "SJ2025";
const ADMIN_CURP   = "ADMIN";
const ADMIN_PASS   = "AdminSJ2025!";

/* ─── design tokens ─────────────────────────────────────────── */
const card = {
  background: "#fff",
  borderRadius: 14,
  border: "1px solid #e2e6f0",
  padding: "24px 22px",
  boxShadow: "0 2px 12px rgba(26,86,164,.06)",
};
const inputStyle = {
  display: "block", width: "100%", padding: "9px 12px",
  border: "1px solid #d0d5e8", borderRadius: 8,
  fontSize: 14, background: "#fff", color: "#1a1a2e",
  fontFamily: "inherit", outline: "none",
};
const selStyle = { ...inputStyle };
const btnPrimary = {
  background: SJB, color: "#fff", border: "none",
  padding: "11px 26px", borderRadius: 9,
  fontSize: 14, fontWeight: 600, cursor: "pointer",
  letterSpacing: .2,
};
const btnSecondary = {
  background: "transparent", color: SJB,
  border: `1px solid ${SJB}`,
  padding: "9px 20px", borderRadius: 9,
  fontSize: 14, fontWeight: 500, cursor: "pointer",
};
const btnGhost = {
  background: "transparent", color: "#6b7a99",
  border: "1px solid #d0d5e8",
  padding: "7px 14px", borderRadius: 8,
  fontSize: 13, cursor: "pointer",
};

/* ─── UI helpers ────────────────────────────────────────────── */
function Field({ label, required, children }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#5a6a8a", marginBottom: 5, textTransform: "uppercase", letterSpacing: .4 }}>
        {label}{required && <span style={{ color: "#e05a30", marginLeft: 2 }}>*</span>}
      </label>
      {children}
    </div>
  );
}
function ReadOnly({ label, value }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#5a6a8a", marginBottom: 5, textTransform: "uppercase", letterSpacing: .4 }}>{label}</label>
      <div style={{ ...inputStyle, background: "#f5f7fc", color: "#4a5a7a", cursor: "default" }}>{value || <span style={{ color: "#b0b8cc" }}>—</span>}</div>
    </div>
  );
}
function SectionTitle({ children }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "22px 0 14px" }}>
      <div style={{ flex: 1, height: 1, background: "#e2e6f0" }} />
      <span style={{ fontSize: 11, fontWeight: 700, color: "#8892aa", textTransform: "uppercase", letterSpacing: .7, whiteSpace: "nowrap" }}>{children}</span>
      <div style={{ flex: 1, height: 1, background: "#e2e6f0" }} />
    </div>
  );
}
function Alert({ type = "info", children }) {
  const styles = {
    success: { bg: "#edfaf3", border: "#a8e6c5", text: "#1a7a45" },
    warning: { bg: "#fffbea", border: "#fde08a", text: "#8a5c00" },
    error:   { bg: "#fff0f0", border: "#f5b8b8", text: "#c0392b" },
    info:    { bg: "#eef4fd", border: "#b8cfef", text: "#1A56A4" },
  };
  const s = styles[type] || styles.info;
  return <div style={{ background: s.bg, border: `1px solid ${s.border}`, color: s.text, borderRadius: 9, padding: "10px 14px", fontSize: 13, marginBottom: 14, lineHeight: 1.5 }}>{children}</div>;
}
function Badge({ color = "blue", children }) {
  const c = {
    blue: { bg: "#eef4fd", text: "#1A56A4" }, green: { bg: "#edfaf3", text: "#1a7a45" },
    amber: { bg: "#fffbea", text: "#8a5c00" }, red: { bg: "#fff0f0", text: "#c0392b" },
    pink: { bg: "#fef0f6", text: "#9c2a60" }, gray: { bg: "#f2f4f8", text: "#5a6a8a" },
  };
  const s = c[color] || c.gray;
  return <span style={{ background: s.bg, color: s.text, fontSize: 11, fontWeight: 600, padding: "2px 8px", borderRadius: 6 }}>{children}</span>;
}
function Grid2({ children }) {
  return <div className="sj-grid2" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 18px" }}>{children}</div>;
}
function Grid3({ children }) {
  return <div className="sj-grid2" style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "0 14px" }}>{children}</div>;
}

/* ─── APP ───────────────────────────────────────────────────── */
export default function App() {
  const [view, setView]   = useState("login");
  const [auth, setAuth]   = useState({});
  const [users, setUsers] = useState({});
  const [me, setMe]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [loginCurp, setLoginCurp] = useState("");
  const [loginPass, setLoginPass] = useState("");
  const [loginErr, setLoginErr]   = useState("");
  const [activeSection, setActiveSection] = useState("perfil");
  const [profileSubTab, setProfileSubTab] = useState("datos");
  const [saveMsg, setSaveMsg]     = useState("");
  const [adminSection, setAdminSection] = useState("lista");
  const [searchQ, setSearchQ]     = useState("");
  const [editTarget, setEditTarget] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeEval, setActiveEval] = useState(null);

  useEffect(() => { bootstrap(); }, []);

  async function bootstrap() {
    setLoading(true);
    let storedAuth = loadAuth();
    let storedUsers = loadUsers();
    if (!storedAuth || Object.keys(storedAuth).length === 0) {
      const newAuth = {}, newUsers = {};
      const ph = await hashPassword(DEFAULT_PASS);
      for (const u of SEED_USERS) {
        const key = u.curp.toUpperCase();
        newAuth[key]  = { passwordHash: ph, mustChange: true };
        newUsers[key] = { ...u, curp: key, evaluaciones: {}, eventos: [], updatedAt: new Date().toISOString() };
      }
      const adminPh = await hashPassword(ADMIN_PASS);
      newAuth[ADMIN_CURP] = { passwordHash: adminPh, mustChange: false };
      saveAuth(newAuth); saveUsers(newUsers);
      setAuth(newAuth); setUsers(newUsers);
    } else {
      // Migración v1.2: renombrar "MJ Sec/Prepa" → "MJ Prepa" en usuarios existentes
      let migrated = false;
      const migUsers = { ...storedUsers };
      for (const k of Object.keys(migUsers)) {
        const oldProg = migUsers[k]?.programa;
        if (oldProg === "MJ Sec/Prepa" || oldProg === "MJ General" || oldProg === "MJ Sec" || oldProg === "MJ") {
          migUsers[k] = { ...migUsers[k], programa: "MJ Prepa" };
          migrated = true;
        }
        if (!migUsers[k].evaluaciones) {
          migUsers[k] = { ...migUsers[k], evaluaciones: {} };
          migrated = true;
        }
        if (!Array.isArray(migUsers[k].eventos)) {
          migUsers[k] = { ...migUsers[k], eventos: [] };
          migrated = true;
        }
      }
      // Añadir usuarios nuevos del seed que no estén en localStorage (por si la BDD creció)
      const ph = await hashPassword(DEFAULT_PASS);
      const migAuth = { ...storedAuth };
      let addedNew = 0;
      for (const u of SEED_USERS) {
        const key = u.curp.toUpperCase();
        if (!migUsers[key]) {
          migUsers[key] = { ...u, curp: key, evaluaciones: {}, updatedAt: new Date().toISOString() };
          migAuth[key] = { passwordHash: ph, mustChange: true };
          addedNew++;
          migrated = true;
        }
      }
      if (migrated) {
        saveUsers(migUsers);
        saveAuth(migAuth);
        if (addedNew > 0) console.log(`Migración v1.2: ${addedNew} usuarios nuevos agregados`);
      }
      setAuth(migAuth); setUsers(migUsers);
    }
    setLoading(false);
  }

  async function login(e) {
    e.preventDefault(); setLoginErr("");
    const key = loginCurp.trim().toUpperCase();
    const ae = auth[key];
    if (!ae) { setLoginErr("CURP no encontrado. Contacta a tu coordinador."); return; }
    const ph = await hashPassword(loginPass);
    if (ph !== ae.passwordHash) { setLoginErr("Contraseña incorrecta. Intenta de nuevo."); return; }
    setLoginPass("");
    if (key === ADMIN_CURP) {
      setMe({ curp: ADMIN_CURP, nombre: "Administrador", tipo: "admin" });
      setView("admin");
    } else {
      setMe(users[key]);
      setView(ae.mustChange ? "changePass" : "dashboard");
    }
  }

  async function changePass(np, cp) {
    if (np.length < 8) return "La contraseña debe tener al menos 8 caracteres.";
    if (np !== cp)     return "Las contraseñas no coinciden.";
    const ph = await hashPassword(np);
    const na = { ...auth, [me.curp]: { ...auth[me.curp], passwordHash: ph, mustChange: false } };
    saveAuth(na); setAuth(na); setView("dashboard");
    return null;
  }

  function notify(msg) {
    setSaveMsg(msg);
    setTimeout(() => setSaveMsg(""), 3500);
  }

  async function saveProfile(updated) {
    const nu = { ...users, [me.curp]: { ...updated, updatedAt: new Date().toISOString() } };
    saveUsers(nu); setUsers(nu); setMe(nu[me.curp]);
    notify("✓ Datos guardados correctamente");
  }

  async function saveEvaluacion(evaluationId, answers) {
    const newEvals = {
      ...(me.evaluaciones || {}),
      [evaluationId]: { completedAt: new Date().toISOString(), answers }
    };
    const updated = { ...me, evaluaciones: newEvals };
    await saveProfile(updated);
    setActiveEval(null);
    notify("✓ Evaluación guardada. ¡Gracias por tu tiempo!");
  }

  async function adminSaveUser(curp, data) {
    const nu = { ...users, [curp]: { ...data, updatedAt: new Date().toISOString() } };
    saveUsers(nu); setUsers(nu); setEditTarget(null);
    notify("✓ Usuario actualizado");
  }

  async function adminAddUser(data) {
    const key = data.curp.toUpperCase();
    const ph  = await hashPassword(DEFAULT_PASS);
    const na  = { ...auth, [key]: { passwordHash: ph, mustChange: true } };
    const nu  = { ...users, [key]: { ...data, curp: key, evaluaciones: {}, eventos: [], registros: { firmaTC: false, cartaResp: false, capacitacion: false }, updatedAt: new Date().toISOString() } };
    saveAuth(na); saveUsers(nu); setAuth(na); setUsers(nu);
    setAdminSection("lista");
    notify(`✓ Registrado. Contraseña temporal: ${DEFAULT_PASS}`);
  }

  async function adminBulkRegisterEvent(entries) {
    // entries: [{ curp, eventData }]
    const nu = { ...users };
    for (const { curp, eventData } of entries) {
      if (!nu[curp]) continue;
      const eventos = [...(nu[curp].eventos || []), eventData];
      nu[curp] = { ...nu[curp], eventos, updatedAt: new Date().toISOString() };
    }
    saveUsers(nu); setUsers(nu);
    notify(`✓ Evento registrado para ${entries.length} participante(s)`);
  }

  async function adminUpdateEvent(curp, eventId, updates) {
    const u = users[curp];
    if (!u) return;
    const eventos = (u.eventos || []).map(e => e.id === eventId ? { ...e, ...updates } : e);
    const nu = { ...users, [curp]: { ...u, eventos, updatedAt: new Date().toISOString() } };
    saveUsers(nu); setUsers(nu);
    notify("✓ Evento actualizado");
  }

  async function adminDeleteEvent(curp, eventId) {
    const u = users[curp];
    if (!u) return;
    const eventos = (u.eventos || []).filter(e => e.id !== eventId);
    const nu = { ...users, [curp]: { ...u, eventos, updatedAt: new Date().toISOString() } };
    saveUsers(nu); setUsers(nu);
    notify("✓ Evento eliminado");
  }

  function logout() {
    setMe(null); setView("login");
    setLoginCurp(""); setLoginPass(""); setLoginErr("");
    setActiveSection("perfil"); setProfileSubTab("datos");
    setAdminSection("lista"); setEditTarget(null);
    setActiveEval(null); setSidebarOpen(false);
  }

  if (loading) return <LoadingScreen />;
  if (view === "login")      return <LoginScreen curp={loginCurp} setCurp={setLoginCurp} pass={loginPass} setPass={setLoginPass} err={loginErr} onLogin={login} />;
  if (view === "changePass") return <ChangePassScreen onSave={changePass} user={me} />;
  if (view === "admin")      return (
    <AdminLayout
      users={users} onLogout={logout}
      saveMsg={saveMsg} section={adminSection} setSection={setAdminSection}
      searchQ={searchQ} setSearchQ={setSearchQ}
      editTarget={editTarget} setEditTarget={setEditTarget}
      onSaveUser={adminSaveUser} onAddUser={adminAddUser}
      onBulkRegisterEvent={adminBulkRegisterEvent}
      onUpdateEvent={adminUpdateEvent}
      onDeleteEvent={adminDeleteEvent}
      sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen}
    />
  );
  return (
    <DashboardLayout
      user={me} onLogout={logout} onSave={saveProfile} saveMsg={saveMsg}
      activeSection={activeSection} setActiveSection={setActiveSection}
      profileSubTab={profileSubTab} setProfileSubTab={setProfileSubTab}
      activeEval={activeEval} setActiveEval={setActiveEval}
      onSaveEval={saveEvaluacion}
      sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen}
    />
  );
}

/* ─── LOADING ───────────────────────────────────────────────── */
function LoadingScreen() {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: "100vh", gap: 18 }}>
      <img src={LOGO_SRC} alt="SJ Logo" style={{ width: 80, height: 80, borderRadius: 16 }} />
      <div style={{ width: 32, height: 32, border: "3px solid #c8d8f0", borderTop: `3px solid ${SJB}`, borderRadius: "50%", animation: "spin .9s linear infinite" }} />
      <p style={{ color: "#8892aa", fontSize: 14 }}>Cargando plataforma…</p>
    </div>
  );
}

/* ─── LOGIN ─────────────────────────────────────────────────── */
function LoginScreen({ curp, setCurp, pass, setPass, err, onLogin }) {
  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "20px 16px" }}>
      <div style={{ width: "100%", maxWidth: 420, animation: "fadeIn .3s ease" }}>
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <img src={LOGO_SRC} alt="Superación Juvenil A.B.P." style={{ width: 88, height: 88, borderRadius: 18, marginBottom: 14, boxShadow: "0 4px 20px rgba(26,86,164,.2)" }} />
          <h1 style={{ fontSize: 22, fontWeight: 700, color: "#1a1a2e", margin: 0 }}>Superación Juvenil A.B.P.</h1>
          <p style={{ color: "#6b7a99", fontSize: 14, marginTop: 5 }}>Plataforma de Seguimiento · BDD Programas</p>
        </div>
        <div style={card}>
          <form onSubmit={onLogin}>
            <Field label="CURP (tu usuario)" required>
              <input value={curp} onChange={e => setCurp(e.target.value.toUpperCase())} placeholder="Ej: DUCA060826MLRBLA7" required maxLength={20} style={{ ...inputStyle, letterSpacing: 1.5, textTransform: "uppercase" }} />
            </Field>
            <Field label="Contraseña" required>
              <input type="password" value={pass} onChange={e => setPass(e.target.value)} placeholder="Tu contraseña" required style={inputStyle} />
            </Field>
            {err && <Alert type="error">{err}</Alert>}
            <button type="submit" style={{ ...btnPrimary, width: "100%", padding: "12px", fontSize: 15, marginTop: 6 }}>Ingresar</button>
          </form>
          <p style={{ fontSize: 12, color: "#9aa5bb", textAlign: "center", marginTop: 16 }}>
            Tu CURP es tu usuario. Primer acceso: utiliza la contraseña temporal que te dio tu coordinador.
          </p>
        </div>
        <p style={{ fontSize: 11, color: "#b0b8cc", textAlign: "center", marginTop: 14 }}>
          Superación Juvenil A.B.P. · Datos protegidos con cifrado SHA-256
        </p>
      </div>
    </div>
  );
}

/* ─── CHANGE PASS ───────────────────────────────────────────── */
function ChangePassScreen({ onSave, user }) {
  const [np, setNp] = useState("");
  const [cp, setCp] = useState("");
  const [err, setErr] = useState("");
  const [show, setShow] = useState(false);
  async function submit(e) { e.preventDefault(); const er = await onSave(np, cp); if (er) setErr(er); }
  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "20px 16px" }}>
      <div style={{ width: "100%", maxWidth: 400 }}>
        <div style={{ textAlign: "center", marginBottom: 24 }}>
          <img src={LOGO_SRC} alt="" style={{ width: 64, height: 64, borderRadius: 13, marginBottom: 12 }} />
          <h2 style={{ fontSize: 20, fontWeight: 700, color: "#1a1a2e" }}>Crea tu contraseña</h2>
          <p style={{ color: "#6b7a99", fontSize: 13, marginTop: 4 }}>Hola {user?.nombre}. Es tu primer acceso.</p>
        </div>
        <Alert type="warning">Por seguridad, debes crear tu propia contraseña antes de continuar. Mínimo 8 caracteres.</Alert>
        <div style={card}>
          <form onSubmit={submit}>
            <Field label="Nueva contraseña" required><input type={show ? "text" : "password"} value={np} onChange={e => setNp(e.target.value)} required style={inputStyle} /></Field>
            <Field label="Confirmar contraseña" required><input type={show ? "text" : "password"} value={cp} onChange={e => setCp(e.target.value)} required style={inputStyle} /></Field>
            <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: "#6b7a99", cursor: "pointer", marginBottom: 14 }}>
              <input type="checkbox" checked={show} onChange={e => setShow(e.target.checked)} style={{ width: "auto" }} />
              Mostrar contraseña
            </label>
            {err && <Alert type="error">{err}</Alert>}
            <button type="submit" style={{ ...btnPrimary, width: "100%", padding: "12px" }}>Guardar y entrar</button>
          </form>
        </div>
      </div>
    </div>
  );
}

/* ─── SIDEBAR ───────────────────────────────────────────────── */
function Sidebar({ items, active, onChange, user, onLogout, isOpen, onClose }) {
  return (
    <>
      {isOpen && <div className="sj-backdrop open" onClick={onClose} />}
      <aside className={`sj-sidebar ${isOpen ? "open" : ""}`}>
        <div style={{ padding: "22px 18px 18px", borderBottom: "1px solid rgba(255,255,255,.12)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
            <img src={LOGO_SRC} alt="" style={{ width: 40, height: 40, borderRadius: 9, background: "#fff" }} />
            <div>
              <p style={{ margin: 0, fontWeight: 700, fontSize: 14, color: "#fff" }}>SJ A.B.P.</p>
              <p style={{ margin: 0, fontSize: 11, color: "rgba(255,255,255,.7)" }}>Plataforma BDD</p>
            </div>
          </div>
        </div>

        {user && (
          <div style={{ padding: "16px 18px", borderBottom: "1px solid rgba(255,255,255,.12)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 38, height: 38, borderRadius: "50%", background: "rgba(255,255,255,.18)", border: "1.5px solid rgba(255,255,255,.4)", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 15, color: "#fff" }}>
                {(user.nombre || "?")[0]?.toUpperCase()}
              </div>
              <div style={{ minWidth: 0, flex: 1 }}>
                <p style={{ margin: 0, fontSize: 13, fontWeight: 600, color: "#fff", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{user.nombre} {user.apPat}</p>
                <p style={{ margin: 0, fontSize: 11, color: "rgba(255,255,255,.65)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{user.tipo === "admin" ? "Administrador" : user.programa || "Participante"}</p>
              </div>
            </div>
          </div>
        )}

        <nav style={{ flex: 1, padding: "12px 10px", display: "flex", flexDirection: "column", gap: 3 }}>
          {items.map(item => {
            const isActive = active === item.id;
            return (
              <button key={item.id}
                onClick={() => { onChange(item.id); onClose && onClose(); }}
                style={{
                  display: "flex", alignItems: "center", gap: 12,
                  padding: "10px 13px", border: "none",
                  background: isActive ? "rgba(255,255,255,.18)" : "transparent",
                  color: "#fff", borderRadius: 9, fontSize: 14,
                  fontWeight: isActive ? 600 : 500, textAlign: "left",
                  width: "100%",
                  borderLeft: isActive ? "3px solid #fff" : "3px solid transparent",
                  paddingLeft: isActive ? 11 : 13,
                }}>
                <span style={{ fontSize: 17, width: 20, textAlign: "center" }}>{item.icon}</span>
                <span>{item.label}</span>
                {item.badge != null && (
                  <span style={{ marginLeft: "auto", background: "rgba(255,255,255,.22)", color: "#fff", fontSize: 11, padding: "1px 7px", borderRadius: 10, fontWeight: 600 }}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        <div style={{ padding: "14px 14px 18px", borderTop: "1px solid rgba(255,255,255,.12)" }}>
          <button onClick={onLogout} style={{
            display: "flex", alignItems: "center", gap: 10,
            padding: "9px 13px", border: "1px solid rgba(255,255,255,.3)",
            background: "rgba(255,255,255,.08)", color: "#fff",
            borderRadius: 9, fontSize: 13, fontWeight: 500,
            width: "100%", justifyContent: "center",
          }}>
            ↩ Cerrar sesión
          </button>
        </div>
      </aside>
    </>
  );
}

/* ─── DASHBOARD LAYOUT (con sidebar) ────────────────────────── */
function DashboardLayout({ user, onLogout, onSave, saveMsg, activeSection, setActiveSection, profileSubTab, setProfileSubTab, activeEval, setActiveEval, onSaveEval, sidebarOpen, setSidebarOpen }) {
  const evals = evaluacionesParaUsuario(user);
  const completedCount = Object.keys(user?.evaluaciones || {}).length;
  const pendingEvals = evals.length - completedCount;

  const items = [
    { id: "perfil",       label: "Perfil",       icon: "👤" },
    { id: "evaluaciones", label: "Evaluaciones", icon: "📝", badge: pendingEvals > 0 ? pendingEvals : null },
  ];

  return (
    <div className="sj-layout">
      <Sidebar items={items} active={activeSection} onChange={setActiveSection}
        user={user} onLogout={onLogout}
        isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <button className="sj-burger" onClick={() => setSidebarOpen(true)} aria-label="Menú">☰</button>

      <main className="sj-main">
        <div style={{ maxWidth: 820, margin: "0 auto" }}>
          {saveMsg && <Alert type="success">{saveMsg}</Alert>}
          {activeSection === "perfil" && (
            <PerfilSection user={user} onSave={onSave} subTab={profileSubTab} setSubTab={setProfileSubTab} />
          )}
          {activeSection === "evaluaciones" && (
            <EvaluacionesSection user={user} evals={evals} activeEval={activeEval} setActiveEval={setActiveEval} onSaveEval={onSaveEval} />
          )}
        </div>
      </main>
    </div>
  );
}

/* ─── PERFIL SECTION ────────────────────────────────────────── */
function PerfilSection({ user, onSave, subTab, setSubTab }) {
  const age = calcAge(user?.fechaNac);
  const minor = isMinor(user?.fechaNac);
  const subTabs = [
    { id: "datos",      label: "Datos personales" },
    { id: "programa",   label: "Programa" },
    { id: "documentos", label: "Documentos" },
  ];
  return (
    <div className="fade-in">
      {/* Profile header */}
      <div style={{ ...card, marginBottom: 18, display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
        <div style={{ width: 54, height: 54, borderRadius: "50%", background: SJBG, border: `2px solid ${SJB}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, fontWeight: 700, color: SJB, flexShrink: 0 }}>
          {(user?.nombre || "?")[0]?.toUpperCase()}
        </div>
        <div style={{ flex: 1, minWidth: 200 }}>
          <p style={{ margin: 0, fontWeight: 700, fontSize: 17, color: "#1a1a2e" }}>{user?.nombre} {user?.apPat} {user?.apMat || ""}</p>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 6, flexWrap: "wrap" }}>
            <span style={{ fontSize: 12, color: "#6b7a99" }}>{user?.curp}</span>
            {age !== null && <Badge color="blue">{age} años</Badge>}
            {minor && <Badge color="pink">Menor de edad</Badge>}
            {user?.programa && <Badge color="green">{user?.programa}</Badge>}
            {user?.distrito && <Badge color="gray">{user?.distrito}</Badge>}
          </div>
        </div>
      </div>

      {/* Sub tabs */}
      <div style={{ display: "flex", gap: 6, marginBottom: 16, borderBottom: "2px solid #e2e6f0", overflowX: "auto" }}>
        {subTabs.map(t => (
          <button key={t.id} onClick={() => setSubTab(t.id)} style={{
            padding: "10px 18px", background: "transparent", border: "none",
            borderBottom: subTab === t.id ? `3px solid ${SJB}` : "3px solid transparent",
            color: subTab === t.id ? SJB : "#6b7a99",
            fontWeight: subTab === t.id ? 700 : 500,
            fontSize: 14, cursor: "pointer", marginBottom: -2, whiteSpace: "nowrap",
          }}>{t.label}</button>
        ))}
      </div>

      {subTab === "datos"      && <DatosTab     user={user} onSave={onSave} />}
      {subTab === "programa"   && <ProgramaTab  user={user} onSave={onSave} />}
      {subTab === "documentos" && <DocumentosTab user={user} onSave={onSave} />}
    </div>
  );
}

/* ─── DATOS TAB ─────────────────────────────────────────────── */
function DatosTab({ user, onSave }) {
  const [form, setForm] = useState({ ...user });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const minor = isMinor(form.fechaNac);
  function onCurpBlur() {
    const { dob, sex } = parseCURP(form.curp);
    if (dob) set("fechaNac", dob);
    if (sex) set("sexo", sex);
  }
  return (
    <div style={card} className="fade-in">
      <SectionTitle>Datos personales</SectionTitle>
      <Grid2>
        <Field label="Nombre(s)" required><input value={form.nombre || ""} onChange={e => set("nombre", e.target.value)} style={inputStyle} /></Field>
        <Field label="Apellido Paterno" required><input value={form.apPat || ""} onChange={e => set("apPat", e.target.value)} style={inputStyle} /></Field>
        <Field label="Apellido Materno"><input value={form.apMat || ""} onChange={e => set("apMat", e.target.value)} style={inputStyle} /></Field>
        <Field label="CURP"><input value={form.curp || ""} disabled onBlur={onCurpBlur} style={{ ...inputStyle, background: "#f5f7fc", color: "#4a5a7a", letterSpacing: 1.5 }} /></Field>
      </Grid2>
      <Grid3>
        <ReadOnly label="Fecha de nacimiento" value={form.fechaNac} />
        <ReadOnly label="Sexo" value={form.sexo} />
        <ReadOnly label="Edad actual" value={calcAge(form.fechaNac) !== null ? `${calcAge(form.fechaNac)} años` : ""} />
      </Grid3>
      <SectionTitle>Domicilio</SectionTitle>
      <Grid2>
        <Field label="Calle y número"><input value={form.calle || ""} onChange={e => set("calle", e.target.value)} style={inputStyle} /></Field>
        <Field label="Colonia"><input value={form.colonia || ""} onChange={e => set("colonia", e.target.value)} style={inputStyle} /></Field>
        <Field label="C.P."><input value={form.cp || ""} onChange={e => set("cp", e.target.value)} style={inputStyle} /></Field>
        <Field label="Municipio"><input value={form.municipio || ""} onChange={e => set("municipio", e.target.value)} style={inputStyle} /></Field>
      </Grid2>
      <SectionTitle>Contacto</SectionTitle>
      <Grid2>
        <Field label="Correo electrónico"><input type="email" value={form.correo || ""} onChange={e => set("correo", e.target.value)} style={inputStyle} /></Field>
        <Field label="Teléfono"><input value={form.tel || ""} onChange={e => set("tel", e.target.value)} style={inputStyle} /></Field>
      </Grid2>
      {minor && (
        <>
          <SectionTitle>Datos del padre / tutor (requerido — menor de edad)</SectionTitle>
          <Grid2>
            <Field label="Nombre del padre o tutor" required><input value={form.nombreTutor || ""} onChange={e => set("nombreTutor", e.target.value)} style={inputStyle} /></Field>
            <Field label="Teléfono de contacto" required><input value={form.telTutor || ""} onChange={e => set("telTutor", e.target.value)} style={inputStyle} /></Field>
            <div style={{ gridColumn: "1/-1" }}>
              <Field label="Correo de contacto"><input type="email" value={form.correoTutor || ""} onChange={e => set("correoTutor", e.target.value)} style={inputStyle} /></Field>
            </div>
          </Grid2>
        </>
      )}
      <div style={{ marginTop: 22 }}>
        <button onClick={() => onSave(form)} style={btnPrimary}>Guardar datos personales</button>
      </div>
    </div>
  );
}

/* ─── PROGRAMA TAB ──────────────────────────────────────────── */
function ProgramaTab({ user, onSave }) {
  const [form, setForm] = useState({ ...user });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const tipo = form.tipo || "beneficiario";
  return (
    <div style={card} className="fade-in">
      <SectionTitle>Participación en SJ A.B.P.</SectionTitle>
      <Grid2>
        <Field label="Tipo de participante">
          <select value={tipo} onChange={e => set("tipo", e.target.value)} style={selStyle}>
            <option value="beneficiario">Beneficiario</option>
            <option value="voluntario">Voluntario</option>
          </select>
        </Field>
        <Field label="Programa">
          <select value={form.programa || ""} onChange={e => set("programa", e.target.value)} style={selStyle}>
            <option value="">Selecciona...</option>
            <option>MJ Prepa</option><option>MCU</option><option>SU</option><option>Essencia</option><option>Escudería Real</option>
          </select>
        </Field>
        <Field label="Distrito">
          <select value={form.distrito || ""} onChange={e => set("distrito", e.target.value)} style={selStyle}>
            <option value="">Selecciona...</option><option>Norte</option><option>Sur</option><option>Poniente</option><option>Oriente</option>
          </select>
        </Field>
        <Field label="Status">
          <select value={form.status || ""} onChange={e => set("status", e.target.value)} style={selStyle}>
            <option value="">Selecciona...</option><option>Activo</option><option>Inactivo</option><option>Pre-alianza</option><option>En camino</option><option>Inicial</option><option>Alianza</option>
          </select>
        </Field>
      </Grid2>
      {tipo === "beneficiario" && (
        <>
          <SectionTitle>Datos escolares</SectionTitle>
          <Grid2>
            <Field label="Grado escolar"><input value={form.grado || ""} onChange={e => set("grado", e.target.value)} style={inputStyle} /></Field>
            <Field label="Escuela / Universidad"><input value={form.escuela || ""} onChange={e => set("escuela", e.target.value)} style={inputStyle} /></Field>
            <div style={{ gridColumn: "1/-1" }}>
              <Field label="Carrera (si aplica)"><input value={form.carrera || ""} onChange={e => set("carrera", e.target.value)} style={inputStyle} /></Field>
            </div>
          </Grid2>
          <SectionTitle>Servicio</SectionTitle>
          <Field label="Servicio dentro de Jésed / SJ"><input value={form.servicioJesed || ""} onChange={e => set("servicioJesed", e.target.value)} style={inputStyle} /></Field>
          <Field label="Voluntariado externo"><input value={form.voluntariado || ""} onChange={e => set("voluntariado", e.target.value)} placeholder="Opcional" style={inputStyle} /></Field>
        </>
      )}
      {tipo === "voluntario" && (
        <>
          <SectionTitle>Información laboral</SectionTitle>
          <Grid2>
            <Field label="Ocupación"><input value={form.ocupacion || ""} onChange={e => set("ocupacion", e.target.value)} style={inputStyle} /></Field>
            <Field label="Empresa / Institución"><input value={form.empresa || ""} onChange={e => set("empresa", e.target.value)} style={inputStyle} /></Field>
          </Grid2>
          <Field label="Programas de SJ en los que has participado">
            <textarea value={form.programasParticipados || ""} onChange={e => set("programasParticipados", e.target.value)} rows={3} style={{ ...inputStyle, resize: "vertical" }} />
          </Field>
        </>
      )}
      <SectionTitle>Seguimiento</SectionTitle>
      <Field label="Notas de seguimiento">
        <textarea value={form.notasSeguimiento || ""} onChange={e => set("notasSeguimiento", e.target.value)} rows={3} style={{ ...inputStyle, resize: "vertical" }} />
      </Field>
      <div style={{ marginTop: 22 }}>
        <button onClick={() => onSave(form)} style={btnPrimary}>Guardar información de programa</button>
      </div>
    </div>
  );
}

/* ─── DOCUMENTOS TAB ────────────────────────────────────────── */
function DocumentosTab({ user, onSave }) {
  const reg = user?.registros || {};
  const [form, setForm] = useState({ ...user, registros: { firmaTC: false, cartaResp: false, capacitacion: false, ...reg } });
  const setReg = (k, v) => setForm(f => ({ ...f, registros: { ...f.registros, [k]: v } }));
  const docs = [
    { key: "firmaTC",     label: "Términos y condiciones",           desc: "Acepto los términos y condiciones de SJ A.B.P." },
    { key: "cartaResp",   label: "Carta responsiva y uso de imagen", desc: "Autorizo el uso de mi imagen en materiales de SJ A.B.P." },
    { key: "capacitacion",label: "Capacitación Fundación Roble",     desc: "He completado la capacitación de Prevención del Abuso Sexual Infantil (PASI)." },
  ];
  return (
    <div style={card} className="fade-in">
      <SectionTitle>Documentos y compromisos</SectionTitle>
      <p style={{ fontSize: 14, color: "#6b7a99", marginTop: 0, marginBottom: 18 }}>Aplica para todos los participantes.</p>
      {docs.map(doc => (
        <div key={doc.key} onClick={() => setReg(doc.key, !form.registros[doc.key])} style={{
          display: "flex", gap: 14, padding: "14px 16px", marginBottom: 10,
          border: form.registros[doc.key] ? `2px solid ${SJB}` : "1px solid #e2e6f0",
          borderRadius: 12, background: form.registros[doc.key] ? SJBG : "#fff",
          cursor: "pointer", transition: "all .15s",
        }}>
          <div style={{ width: 24, height: 24, borderRadius: 7, flexShrink: 0, marginTop: 1, background: form.registros[doc.key] ? SJB : "#fff", border: form.registros[doc.key] ? "none" : "2px solid #c0c8dc", display: "flex", alignItems: "center", justifyContent: "center" }}>
            {form.registros[doc.key] && <span style={{ color: "#fff", fontSize: 14 }}>✓</span>}
          </div>
          <div>
            <p style={{ margin: 0, fontWeight: 600, fontSize: 14, color: form.registros[doc.key] ? SJBD : "#1a1a2e" }}>{doc.label}</p>
            <p style={{ margin: "3px 0 0", fontSize: 13, color: form.registros[doc.key] ? SJB : "#6b7a99", lineHeight: 1.5 }}>{doc.desc}</p>
          </div>
        </div>
      ))}
      {form.registros.capacitacion && (
        <div style={{ marginLeft: 38, marginTop: -4, marginBottom: 16 }}>
          <Field label="Fecha de capacitación Roble">
            <input type="date" value={form.fechaCapacitacion || ""} onChange={e => setForm(f => ({ ...f, fechaCapacitacion: e.target.value }))} style={{ ...inputStyle, maxWidth: 200 }} />
          </Field>
        </div>
      )}
      <div style={{ marginTop: 22 }}>
        <button onClick={() => onSave(form)} style={btnPrimary}>Guardar documentos</button>
      </div>
    </div>
  );
}

/* ─── EVALUACIONES SECTION ──────────────────────────────────── */
function EvaluacionesSection({ user, evals, activeEval, setActiveEval, onSaveEval }) {
  if (activeEval) {
    const ev = EVALUACIONES.find(e => e.id === activeEval);
    if (!ev) { setActiveEval(null); return null; }
    return <EvalForm
      eval={ev}
      previous={user?.evaluaciones?.[ev.id]}
      onCancel={() => setActiveEval(null)}
      onSubmit={answers => onSaveEval(ev.id, answers)}
    />;
  }
  const completedIds = Object.keys(user?.evaluaciones || {});
  return (
    <div className="fade-in">
      <div style={{ ...card, marginBottom: 18 }}>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: "#1a1a2e" }}>📝 Mis evaluaciones</h2>
        <p style={{ margin: "6px 0 0", fontSize: 14, color: "#6b7a99", lineHeight: 1.5 }}>
          Estas evaluaciones nos ayudan a conocerte mejor, dar seguimiento a tu camino y mejorar nuestros programas. Puedes responderlas a tu propio ritmo.
        </p>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {evals.length === 0 && (
          <Alert type="info">No hay evaluaciones disponibles para tu perfil en este momento.</Alert>
        )}
        {evals.map(ev => {
          const cat = CATEGORIAS[ev.category] || CATEGORIAS.diagnostico;
          const completed = completedIds.includes(ev.id);
          const submission = user?.evaluaciones?.[ev.id];
          return (
            <div key={ev.id} style={{ ...card, padding: "18px 20px", cursor: "pointer", transition: "transform .12s, box-shadow .12s", borderLeft: `4px solid ${cat.color}` }}
              onClick={() => setActiveEval(ev.id)}
              onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 8px 24px rgba(26,86,164,.12)"; }}
              onMouseLeave={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.boxShadow = "0 2px 12px rgba(26,86,164,.06)"; }}>
              <div style={{ display: "flex", alignItems: "flex-start", gap: 14 }}>
                <div style={{ width: 44, height: 44, borderRadius: 11, background: cat.bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 }}>{cat.icon}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", marginBottom: 4 }}>
                    <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: "#1a1a2e" }}>{ev.title}</h3>
                    <Badge color={completed ? "green" : "blue"}>{completed ? "✓ Completada" : "Pendiente"}</Badge>
                  </div>
                  <p style={{ margin: "2px 0 8px", fontSize: 13, color: "#6b7a99", lineHeight: 1.5 }}>{ev.description}</p>
                  <div style={{ display: "flex", alignItems: "center", gap: 12, fontSize: 12, color: "#8892aa" }}>
                    <span>📋 {ev.questions.length} preguntas</span>
                    {ev.estimatedMinutes && <span>⏱ ~{ev.estimatedMinutes} min</span>}
                    <span style={{ color: cat.color, fontWeight: 600 }}>{cat.label}</span>
                  </div>
                  {completed && submission && (
                    <p style={{ margin: "8px 0 0", fontSize: 12, color: "#1a7a45" }}>
                      Completada el {new Date(submission.completedAt).toLocaleDateString("es-MX", { day: "numeric", month: "long", year: "numeric" })} · Toca para ver o editar
                    </p>
                  )}
                </div>
                <div style={{ alignSelf: "center", color: cat.color, fontSize: 18 }}>→</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ─── EVAL FORM ─────────────────────────────────────────────── */
function EvalForm({ eval: ev, previous, onCancel, onSubmit }) {
  const [answers, setAnswers] = useState(previous?.answers || {});
  const [err, setErr] = useState("");
  const cat = CATEGORIAS[ev.category] || CATEGORIAS.diagnostico;

  function setAns(qId, value) {
    setAnswers(a => ({ ...a, [qId]: value }));
    setErr("");
  }

  function toggleMulti(qId, opt, maxSelect) {
    const current = answers[qId] || [];
    if (current.includes(opt)) {
      setAns(qId, current.filter(o => o !== opt));
    } else {
      if (maxSelect && current.length >= maxSelect) {
        setErr(`Solo puedes seleccionar hasta ${maxSelect} opciones.`);
        return;
      }
      setAns(qId, [...current, opt]);
    }
  }

  function submit() {
    for (const q of ev.questions) {
      if (q.required) {
        const v = answers[q.id];
        const empty = v == null || v === "" || (Array.isArray(v) && v.length === 0);
        if (empty) {
          setErr(`Por favor responde la pregunta: "${q.question}"`);
          document.getElementById(`q-${q.id}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
          return;
        }
      }
    }
    setErr("");
    onSubmit(answers);
  }

  return (
    <div className="fade-in">
      <div style={{ ...card, marginBottom: 16, borderLeft: `4px solid ${cat.color}` }}>
        <button onClick={onCancel} style={{ ...btnGhost, marginBottom: 12, fontSize: 12, padding: "5px 12px" }}>← Volver</button>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
          <span style={{ fontSize: 28 }}>{cat.icon}</span>
          <div style={{ flex: 1 }}>
            <h2 style={{ margin: 0, fontSize: 19, fontWeight: 700, color: "#1a1a2e" }}>{ev.title}</h2>
            <p style={{ margin: "3px 0 0", fontSize: 13, color: cat.color, fontWeight: 600 }}>{cat.label} · {ev.questions.length} preguntas</p>
          </div>
        </div>
        <p style={{ margin: 0, fontSize: 14, color: "#6b7a99", lineHeight: 1.55 }}>{ev.description}</p>
        {previous && (
          <Alert type="info">
            Ya respondiste esta evaluación el {new Date(previous.completedAt).toLocaleDateString("es-MX")}. Puedes actualizar tus respuestas si lo deseas.
          </Alert>
        )}
      </div>

      {ev.questions.map((q, idx) => (
        <div key={q.id} id={`q-${q.id}`} style={{ ...card, marginBottom: 12 }}>
          <div style={{ display: "flex", gap: 12, marginBottom: 10 }}>
            <div style={{ width: 26, height: 26, borderRadius: "50%", background: SJBG, color: SJB, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700, flexShrink: 0 }}>{idx + 1}</div>
            <p style={{ margin: 0, fontSize: 15, fontWeight: 600, color: "#1a1a2e", lineHeight: 1.5 }}>
              {q.question}
              {q.required && <span style={{ color: "#e05a30", marginLeft: 4 }}>*</span>}
            </p>
          </div>
          <div style={{ paddingLeft: 38 }}>
            {q.type === "text"     && <input value={answers[q.id] || ""} onChange={e => setAns(q.id, e.target.value)} style={inputStyle} />}
            {q.type === "longtext" && <textarea value={answers[q.id] || ""} onChange={e => setAns(q.id, e.target.value)} rows={3} style={{ ...inputStyle, resize: "vertical", minHeight: 80 }} placeholder="Escribe tu respuesta aquí..." />}
            {q.type === "single"   && (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {q.options.map(opt => {
                  const sel = answers[q.id] === opt;
                  return (
                    <label key={opt} onClick={() => setAns(q.id, opt)} style={{
                      display: "flex", alignItems: "center", gap: 10, padding: "9px 13px",
                      border: sel ? `2px solid ${SJB}` : "1px solid #d0d5e8",
                      borderRadius: 9, background: sel ? SJBG : "#fff",
                      cursor: "pointer", fontSize: 14, color: sel ? SJBD : "#1a1a2e", fontWeight: sel ? 600 : 500,
                    }}>
                      <span style={{ width: 18, height: 18, borderRadius: "50%", border: sel ? `5px solid ${SJB}` : "2px solid #c0c8dc", flexShrink: 0 }} />
                      {opt}
                    </label>
                  );
                })}
              </div>
            )}
            {q.type === "multi" && (
              <div>
                {q.maxSelect && <p style={{ fontSize: 12, color: "#8892aa", margin: "0 0 8px" }}>Selecciona hasta {q.maxSelect}</p>}
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                  {q.options.map(opt => {
                    const sel = (answers[q.id] || []).includes(opt);
                    return (
                      <button key={opt} type="button" onClick={() => toggleMulti(q.id, opt, q.maxSelect)} style={{
                        padding: "7px 14px", borderRadius: 20,
                        border: sel ? `2px solid ${SJB}` : "1px solid #d0d5e8",
                        background: sel ? SJB : "#fff",
                        color: sel ? "#fff" : "#1a1a2e",
                        fontSize: 13, fontWeight: sel ? 600 : 500,
                      }}>{sel ? "✓ " : ""}{opt}</button>
                    );
                  })}
                </div>
              </div>
            )}
            {q.type === "scale" && (
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
                <span style={{ fontSize: 12, color: "#8892aa" }}>1</span>
                {[1, 2, 3, 4, 5].map(n => {
                  const sel = answers[q.id] === n;
                  return (
                    <button key={n} type="button" onClick={() => setAns(q.id, n)} style={{
                      width: 44, height: 44, borderRadius: 9,
                      border: sel ? `2px solid ${SJB}` : "1px solid #d0d5e8",
                      background: sel ? SJB : "#fff",
                      color: sel ? "#fff" : "#1a1a2e",
                      fontSize: 16, fontWeight: 700,
                    }}>{n}</button>
                  );
                })}
                <span style={{ fontSize: 12, color: "#8892aa" }}>5</span>
              </div>
            )}
          </div>
        </div>
      ))}

      {err && <Alert type="error">{err}</Alert>}

      <div style={{ ...card, display: "flex", gap: 12, justifyContent: "space-between", alignItems: "center", flexWrap: "wrap" }}>
        <p style={{ margin: 0, fontSize: 13, color: "#6b7a99" }}>
          {Object.keys(answers).length} de {ev.questions.length} preguntas respondidas
        </p>
        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={onCancel} style={btnSecondary}>Cancelar</button>
          <button onClick={submit} style={btnPrimary}>Guardar evaluación</button>
        </div>
      </div>
    </div>
  );
}

/* ─── ADMIN LAYOUT ──────────────────────────────────────────── */
function AdminLayout({ users, onLogout, saveMsg, section, setSection, searchQ, setSearchQ, editTarget, setEditTarget, onSaveUser, onAddUser, onBulkRegisterEvent, onUpdateEvent, onDeleteEvent, sidebarOpen, setSidebarOpen }) {
  const all = Object.values(users).filter(u => u.curp !== ADMIN_CURP);
  const totalEvents = all.reduce((acc, u) => acc + ((u.eventos || []).length), 0);
  const stats = {
    total: all.length,
    benef: all.filter(u => u.tipo === "beneficiario" || !u.tipo).length,
    vol: all.filter(u => u.tipo === "voluntario").length,
    menores: all.filter(u => isMinor(u.fechaNac)).length,
    docsPend: all.filter(u => !u.registros?.firmaTC || !u.registros?.cartaResp || !u.registros?.capacitacion).length,
    evalsCompletadas: all.reduce((acc, u) => acc + Object.keys(u.evaluaciones || {}).length, 0),
    eventosTotal: totalEvents,
  };
  const adminUser = { nombre: "Administrador", apPat: "", tipo: "admin" };
  const items = [
    { id: "lista",        label: "Usuarios",      icon: "👥", badge: all.length },
    { id: "agregar",      label: "Agregar",       icon: "➕" },
    { id: "evaluaciones", label: "Evaluaciones",  icon: "📝", badge: stats.evalsCompletadas },
    { id: "eventos",      label: "Eventos",       icon: "🎯", badge: stats.eventosTotal || null },
  ];
  return (
    <div className="sj-layout">
      <Sidebar items={items} active={section} onChange={(id) => { setSection(id); setEditTarget(null); }}
        user={adminUser} onLogout={onLogout}
        isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <button className="sj-burger" onClick={() => setSidebarOpen(true)} aria-label="Menú">☰</button>

      <main className="sj-main">
        <div style={{ maxWidth: 900, margin: "0 auto" }}>
          {saveMsg && <Alert type="success">{saveMsg}</Alert>}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))", gap: 12, marginBottom: 22 }}>
            {[
              ["Total",         stats.total,             SJB],
              ["Beneficiarios", stats.benef,             "#1a7a45"],
              ["Voluntarios",   stats.vol,               "#8a5c00"],
              ["Menores",       stats.menores,           "#9c2a60"],
              ["Docs pend.",    stats.docsPend,          "#c0392b"],
              ["Eval. compl.",  stats.evalsCompletadas,  "#1A56A4"],
              ["Eventos",       stats.eventosTotal,      "#7c3aed"],
            ].map(([l, v, c]) => (
              <div key={l} style={{ background: "#fff", border: "1px solid #e2e6f0", borderRadius: 12, padding: "13px 15px", boxShadow: "0 1px 6px rgba(26,86,164,.05)" }}>
                <p style={{ margin: 0, fontSize: 11, fontWeight: 600, color: "#8892aa", textTransform: "uppercase", letterSpacing: .4 }}>{l}</p>
                <p style={{ margin: "5px 0 0", fontSize: 24, fontWeight: 700, color: c }}>{v}</p>
              </div>
            ))}
          </div>

          {section === "lista" && !editTarget && <AdminUsersList users={all} searchQ={searchQ} setSearchQ={setSearchQ} onEdit={setEditTarget} />}
          {section === "lista" &&  editTarget && <AdminEditUser user={editTarget} onSave={onSaveUser} onCancel={() => setEditTarget(null)} onUpdateEvent={onUpdateEvent} onDeleteEvent={onDeleteEvent} />}
          {section === "agregar" && <AdminAddUser onAdd={onAddUser} defaultPass={DEFAULT_PASS} />}
          {section === "evaluaciones" && <AdminEvalSummary users={all} />}
          {section === "eventos" && <AdminEventosSection users={all} onBulkRegister={onBulkRegisterEvent} onUpdateEvent={onUpdateEvent} onDeleteEvent={onDeleteEvent} />}
        </div>
      </main>
    </div>
  );
}

/* ─── ADMIN USERS LIST ──────────────────────────────────────── */
function AdminUsersList({ users, searchQ, setSearchQ, onEdit }) {
  const filtered = users.filter(u => {
    const q = searchQ.toLowerCase();
    return !q || u.curp?.toLowerCase().includes(q) || u.nombre?.toLowerCase().includes(q) || u.apPat?.toLowerCase().includes(q) || u.programa?.toLowerCase().includes(q) || u.municipio?.toLowerCase().includes(q) || u.distrito?.toLowerCase().includes(q);
  });
  return (
    <div style={card}>
      <input value={searchQ} onChange={e => setSearchQ(e.target.value)} placeholder="Buscar por CURP, nombre, programa, distrito…" style={{ ...inputStyle, marginBottom: 14 }} />
      <p style={{ fontSize: 12, color: "#8892aa", marginBottom: 10 }}>Mostrando {filtered.length} de {users.length} participantes</p>
      <div style={{ border: "1px solid #e2e6f0", borderRadius: 10, overflow: "hidden" }}>
        {filtered.length === 0 && <p style={{ padding: 24, textAlign: "center", color: "#8892aa", fontSize: 14 }}>Sin resultados</p>}
        {filtered.map((u, i) => {
          const evalCount = Object.keys(u.evaluaciones || {}).length;
          return (
            <div key={u.curp} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "11px 14px", borderBottom: i < filtered.length - 1 ? "1px solid #f0f2f8" : "none", background: "#fff" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0, flex: 1 }}>
                <div style={{ width: 36, height: 36, borderRadius: "50%", background: isMinor(u.fechaNac) ? "#fef0f6" : SJBG, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700, color: isMinor(u.fechaNac) ? "#9c2a60" : SJB, flexShrink: 0, border: `1.5px solid ${isMinor(u.fechaNac) ? "#f0b8d4" : "#b8cff0"}` }}>{(u.nombre || "?")[0]?.toUpperCase()}</div>
                <div style={{ minWidth: 0, flex: 1 }}>
                  <p style={{ margin: 0, fontSize: 14, fontWeight: 600, color: "#1a1a2e", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{u.nombre} {u.apPat} {u.apMat || ""}</p>
                  <p style={{ margin: 0, fontSize: 12, color: "#8892aa", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{u.curp} · {u.programa || "Sin programa"} · {u.distrito || ""}{calcAge(u.fechaNac) !== null ? ` · ${calcAge(u.fechaNac)}a` : ""}</p>
                </div>
              </div>
              <div style={{ display: "flex", gap: 5, alignItems: "center", flexShrink: 0, marginLeft: 8 }}>
                {evalCount > 0 && <Badge color="green">{evalCount} eval</Badge>}
                {(!u.registros?.firmaTC || !u.registros?.cartaResp || !u.registros?.capacitacion) && <Badge color="amber">Docs</Badge>}
                {isMinor(u.fechaNac) && <Badge color="pink">Menor</Badge>}
                <button onClick={() => onEdit(u)} style={{ ...btnGhost, padding: "5px 12px", fontSize: 12 }}>Editar</button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ─── ADMIN EDIT USER ───────────────────────────────────────── */
function AdminEditUser({ user, onSave, onCancel, onUpdateEvent, onDeleteEvent }) {
  const [form, setForm] = useState({ ...user });
  const [tab, setTab] = useState("datos");
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const setReg = (k, v) => setForm(f => ({ ...f, registros: { ...f.registros, [k]: v } }));
  const minor = isMinor(form.fechaNac);
  const userEvals = evaluacionesParaUsuario(user);
  const eventosCount = (user.eventos || []).length;
  const tabs = [
    { id: "datos", label: "Datos personales" },
    { id: "programa", label: "Programa" },
    { id: "docs", label: "Documentos" },
    { id: "evals", label: `Evaluaciones (${Object.keys(form.evaluaciones || {}).length})` },
    { id: "eventos", label: `Eventos (${eventosCount})` },
  ];

  return (
    <div style={card}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14, flexWrap: "wrap" }}>
        <button onClick={onCancel} style={{ ...btnSecondary, padding: "7px 14px", fontSize: 13 }}>← Volver</button>
        <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#1a1a2e" }}>Editar: {user.nombre} {user.apPat}</h2>
      </div>
      <div style={{ display: "flex", gap: 6, marginBottom: 14, borderBottom: "2px solid #e2e6f0", overflowX: "auto" }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            padding: "9px 14px", background: "transparent", border: "none",
            borderBottom: tab === t.id ? `3px solid ${SJB}` : "3px solid transparent",
            color: tab === t.id ? SJB : "#6b7a99",
            fontWeight: tab === t.id ? 700 : 500,
            fontSize: 13, cursor: "pointer", marginBottom: -2, whiteSpace: "nowrap",
          }}>{t.label}</button>
        ))}
      </div>

      {tab === "datos" && (
        <>
          <Grid2>
            <Field label="Nombre(s)"><input value={form.nombre || ""} onChange={e => set("nombre", e.target.value)} style={inputStyle} /></Field>
            <Field label="Apellido Paterno"><input value={form.apPat || ""} onChange={e => set("apPat", e.target.value)} style={inputStyle} /></Field>
            <Field label="Apellido Materno"><input value={form.apMat || ""} onChange={e => set("apMat", e.target.value)} style={inputStyle} /></Field>
            <ReadOnly label="CURP" value={form.curp} />
            <ReadOnly label="Fecha nac." value={form.fechaNac} />
            <ReadOnly label="Edad" value={calcAge(form.fechaNac) !== null ? `${calcAge(form.fechaNac)} años` : ""} />
          </Grid2>
          <Grid2>
            <Field label="Calle"><input value={form.calle || ""} onChange={e => set("calle", e.target.value)} style={inputStyle} /></Field>
            <Field label="Colonia"><input value={form.colonia || ""} onChange={e => set("colonia", e.target.value)} style={inputStyle} /></Field>
            <Field label="C.P."><input value={form.cp || ""} onChange={e => set("cp", e.target.value)} style={inputStyle} /></Field>
            <Field label="Municipio"><input value={form.municipio || ""} onChange={e => set("municipio", e.target.value)} style={inputStyle} /></Field>
            <Field label="Correo"><input type="email" value={form.correo || ""} onChange={e => set("correo", e.target.value)} style={inputStyle} /></Field>
            <Field label="Teléfono"><input value={form.tel || ""} onChange={e => set("tel", e.target.value)} style={inputStyle} /></Field>
          </Grid2>
          {minor && (
            <>
              <SectionTitle>Tutor</SectionTitle>
              <Grid2>
                <Field label="Nombre tutor"><input value={form.nombreTutor || ""} onChange={e => set("nombreTutor", e.target.value)} style={inputStyle} /></Field>
                <Field label="Teléfono tutor"><input value={form.telTutor || ""} onChange={e => set("telTutor", e.target.value)} style={inputStyle} /></Field>
                <div style={{ gridColumn: "1/-1" }}><Field label="Correo tutor"><input type="email" value={form.correoTutor || ""} onChange={e => set("correoTutor", e.target.value)} style={inputStyle} /></Field></div>
              </Grid2>
            </>
          )}
        </>
      )}

      {tab === "programa" && (
        <>
          <Grid2>
            <Field label="Tipo">
              <select value={form.tipo || "beneficiario"} onChange={e => set("tipo", e.target.value)} style={selStyle}>
                <option value="beneficiario">Beneficiario</option><option value="voluntario">Voluntario</option>
              </select>
            </Field>
            <Field label="Programa">
              <select value={form.programa || ""} onChange={e => set("programa", e.target.value)} style={selStyle}>
                <option value="">Selecciona...</option>
                <option>MJ Prepa</option><option>MCU</option><option>SU</option><option>Essencia</option><option>Escudería Real</option>
              </select>
            </Field>
            <Field label="Distrito">
              <select value={form.distrito || ""} onChange={e => set("distrito", e.target.value)} style={selStyle}>
                <option value="">Selecciona...</option><option>Norte</option><option>Sur</option><option>Poniente</option><option>Oriente</option>
              </select>
            </Field>
            <Field label="Status">
              <select value={form.status || ""} onChange={e => set("status", e.target.value)} style={selStyle}>
                <option value="">Selecciona...</option><option>Activo</option><option>Inactivo</option><option>Pre-alianza</option><option>En camino</option><option>Inicial</option><option>Alianza</option>
              </select>
            </Field>
          </Grid2>
          <Field label="Servicio en SJ / Jésed"><input value={form.servicioJesed || ""} onChange={e => set("servicioJesed", e.target.value)} style={inputStyle} /></Field>
          <Grid3>
            <Field label="Grado"><input value={form.grado || ""} onChange={e => set("grado", e.target.value)} style={inputStyle} /></Field>
            <Field label="Escuela"><input value={form.escuela || ""} onChange={e => set("escuela", e.target.value)} style={inputStyle} /></Field>
            <Field label="Carrera"><input value={form.carrera || ""} onChange={e => set("carrera", e.target.value)} style={inputStyle} /></Field>
          </Grid3>
          <Field label="Notas de seguimiento"><textarea value={form.notasSeguimiento || ""} onChange={e => set("notasSeguimiento", e.target.value)} rows={2} style={{ ...inputStyle, resize: "vertical" }} /></Field>
        </>
      )}

      {tab === "docs" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {[["firmaTC", "Términos y condiciones"], ["cartaResp", "Carta responsiva / uso de imagen"], ["capacitacion", "Capacitación Fundación Roble (PASI)"]].map(([k, l]) => (
            <label key={k} style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer", fontSize: 14, color: "#1a1a2e" }}>
              <input type="checkbox" checked={!!(form.registros?.[k])} onChange={e => setReg(k, e.target.checked)} style={{ width: "auto" }} />
              {l}
            </label>
          ))}
        </div>
      )}

      {tab === "evals" && (
        <div>
          {userEvals.length === 0 && <p style={{ color: "#8892aa", fontSize: 14 }}>No hay evaluaciones aplicables.</p>}
          {userEvals.map(ev => {
            const sub = form.evaluaciones?.[ev.id];
            const cat = CATEGORIAS[ev.category];
            return (
              <div key={ev.id} style={{ border: "1px solid #e2e6f0", borderRadius: 11, padding: "13px 16px", marginBottom: 10, background: sub ? "#fafcff" : "#fff" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8, flexWrap: "wrap", gap: 6 }}>
                  <div>
                    <p style={{ margin: 0, fontWeight: 600, fontSize: 14, color: "#1a1a2e" }}>{cat.icon} {ev.title}</p>
                    <p style={{ margin: "2px 0 0", fontSize: 12, color: "#8892aa" }}>{cat.label}</p>
                  </div>
                  {sub ? <Badge color="green">✓ Respondida {new Date(sub.completedAt).toLocaleDateString("es-MX")}</Badge> : <Badge color="gray">Pendiente</Badge>}
                </div>
                {sub && (
                  <details style={{ marginTop: 8 }}>
                    <summary style={{ fontSize: 13, color: SJB, cursor: "pointer", fontWeight: 600 }}>Ver respuestas</summary>
                    <div style={{ marginTop: 10, padding: "10px 12px", background: "#f5f7fc", borderRadius: 8, fontSize: 13 }}>
                      {ev.questions.map((q, i) => {
                        const a = sub.answers?.[q.id];
                        const display = Array.isArray(a) ? a.join(", ") : a;
                        return (
                          <div key={q.id} style={{ marginBottom: 8, paddingBottom: 8, borderBottom: i < ev.questions.length - 1 ? "1px solid #e2e6f0" : "none" }}>
                            <p style={{ margin: 0, fontSize: 12, color: "#5a6a8a", fontWeight: 600 }}>{i + 1}. {q.question}</p>
                            <p style={{ margin: "3px 0 0", color: display ? "#1a1a2e" : "#b0b8cc" }}>{display || "(Sin respuesta)"}</p>
                          </div>
                        );
                      })}
                    </div>
                  </details>
                )}
              </div>
            );
          })}
        </div>
      )}

      {tab === "eventos" && (
        <UserEventsList
          user={user}
          onUpdate={(eventId, updates) => onUpdateEvent(user.curp, eventId, updates)}
          onDelete={(eventId) => onDeleteEvent(user.curp, eventId)}
        />
      )}

      <div style={{ marginTop: 22, display: "flex", gap: 12 }}>
        <button onClick={() => onSave(user.curp, form)} style={btnPrimary}>Guardar cambios</button>
        <button onClick={onCancel} style={btnSecondary}>Cancelar</button>
      </div>
    </div>
  );
}

/* ─── ADMIN ADD USER ────────────────────────────────────────── */
function AdminAddUser({ onAdd, defaultPass }) {
  const [form, setForm] = useState({ tipo: "beneficiario", programa: "", distrito: "" });
  const [err, setErr] = useState("");
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const minor = isMinor(form.fechaNac);
  function onCurpChange(val) {
    const c = val.toUpperCase();
    const { dob, sex } = parseCURP(c);
    setForm(f => ({ ...f, curp: c, ...(dob ? { fechaNac: dob, sexo: sex } : {}) }));
  }
  async function submit(e) {
    e.preventDefault();
    if (!form.curp || form.curp.length < 18) { setErr("El CURP debe tener 18 caracteres."); return; }
    if (!form.nombre || !form.apPat) { setErr("Nombre y apellido paterno son obligatorios."); return; }
    setErr(""); await onAdd(form);
  }
  return (
    <div style={card}>
      <h2 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 700 }}>Registrar nuevo participante</h2>
      <Alert type="info">Se creará la cuenta con la contraseña temporal: <strong>{defaultPass}</strong>. El participante deberá cambiarla en su primer acceso.</Alert>
      <form onSubmit={submit}>
        <SectionTitle>Datos personales</SectionTitle>
        <Field label="CURP" required><input value={form.curp || ""} onChange={e => onCurpChange(e.target.value)} maxLength={18} style={{ ...inputStyle, letterSpacing: 1.5, textTransform: "uppercase" }} /></Field>
        {form.fechaNac && (
          <div style={{ background: "#f0f2f8", borderRadius: 8, padding: "8px 12px", fontSize: 13, color: "#5a6a8a", marginBottom: 14 }}>
            Del CURP → Nacimiento: <strong>{form.fechaNac}</strong> · Sexo: <strong>{form.sexo}</strong> · {calcAge(form.fechaNac)} años{isMinor(form.fechaNac) ? " · ⚠️ Menor de edad" : ""}
          </div>
        )}
        <Grid2>
          <Field label="Nombre(s)" required><input value={form.nombre || ""} onChange={e => set("nombre", e.target.value)} style={inputStyle} /></Field>
          <Field label="Apellido Paterno" required><input value={form.apPat || ""} onChange={e => set("apPat", e.target.value)} style={inputStyle} /></Field>
          <Field label="Apellido Materno"><input value={form.apMat || ""} onChange={e => set("apMat", e.target.value)} style={inputStyle} /></Field>
        </Grid2>
        <SectionTitle>Domicilio y contacto</SectionTitle>
        <Grid2>
          <Field label="Calle"><input value={form.calle || ""} onChange={e => set("calle", e.target.value)} style={inputStyle} /></Field>
          <Field label="Colonia"><input value={form.colonia || ""} onChange={e => set("colonia", e.target.value)} style={inputStyle} /></Field>
          <Field label="C.P."><input value={form.cp || ""} onChange={e => set("cp", e.target.value)} style={inputStyle} /></Field>
          <Field label="Municipio"><input value={form.municipio || ""} onChange={e => set("municipio", e.target.value)} style={inputStyle} /></Field>
          <Field label="Correo"><input type="email" value={form.correo || ""} onChange={e => set("correo", e.target.value)} style={inputStyle} /></Field>
          <Field label="Teléfono"><input value={form.tel || ""} onChange={e => set("tel", e.target.value)} style={inputStyle} /></Field>
        </Grid2>
        {minor && (
          <>
            <SectionTitle>Tutor (menor de edad)</SectionTitle>
            <Grid2>
              <Field label="Nombre padre/tutor" required><input value={form.nombreTutor || ""} onChange={e => set("nombreTutor", e.target.value)} style={inputStyle} /></Field>
              <Field label="Teléfono tutor" required><input value={form.telTutor || ""} onChange={e => set("telTutor", e.target.value)} style={inputStyle} /></Field>
              <div style={{ gridColumn: "1/-1" }}><Field label="Correo tutor"><input type="email" value={form.correoTutor || ""} onChange={e => set("correoTutor", e.target.value)} style={inputStyle} /></Field></div>
            </Grid2>
          </>
        )}
        <SectionTitle>Programa</SectionTitle>
        <Grid2>
          <Field label="Tipo">
            <select value={form.tipo} onChange={e => set("tipo", e.target.value)} style={selStyle}>
              <option value="beneficiario">Beneficiario</option><option value="voluntario">Voluntario</option>
            </select>
          </Field>
          <Field label="Programa">
            <select value={form.programa} onChange={e => set("programa", e.target.value)} style={selStyle}>
              <option value="">Selecciona...</option><option>MJ Prepa</option><option>MCU</option><option>SU</option><option>Essencia</option><option>Escudería Real</option>
            </select>
          </Field>
          <Field label="Distrito">
            <select value={form.distrito} onChange={e => set("distrito", e.target.value)} style={selStyle}>
              <option value="">Selecciona...</option><option>Norte</option><option>Sur</option><option>Poniente</option><option>Oriente</option>
            </select>
          </Field>
        </Grid2>
        {err && <Alert type="error">{err}</Alert>}
        <button type="submit" style={{ ...btnPrimary, marginTop: 8 }}>Registrar participante</button>
      </form>
    </div>
  );
}

/* ─── ADMIN EVAL SUMMARY ────────────────────────────────────── */
function AdminEvalSummary({ users }) {
  const summary = EVALUACIONES.map(ev => {
    const applicable = users.filter(u => {
      const a = ev.applies || {};
      if (a.tipo && a.tipo.length && !a.tipo.includes(u.tipo || "beneficiario")) return false;
      if (a.programa && a.programa.length && !a.programa.includes(u.programa)) return false;
      return true;
    });
    const completed = applicable.filter(u => u.evaluaciones && u.evaluaciones[ev.id]).length;
    return { ev, total: applicable.length, completed };
  });
  return (
    <div style={card}>
      <h2 style={{ margin: "0 0 6px", fontSize: 17, fontWeight: 700 }}>📝 Resumen de evaluaciones</h2>
      <p style={{ margin: "0 0 18px", fontSize: 13, color: "#6b7a99" }}>
        Vista general de evaluaciones aplicables y respondidas. Para ver respuestas individuales, abre el perfil del usuario y ve a la pestaña "Evaluaciones".
      </p>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {summary.map(({ ev, total, completed }) => {
          const cat = CATEGORIAS[ev.category];
          const pct = total > 0 ? Math.round((completed / total) * 100) : 0;
          return (
            <div key={ev.id} style={{ border: "1px solid #e2e6f0", borderRadius: 11, padding: "14px 16px", borderLeft: `4px solid ${cat.color}` }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
                <div>
                  <p style={{ margin: 0, fontWeight: 700, fontSize: 14, color: "#1a1a2e" }}>{cat.icon} {ev.title}</p>
                  <p style={{ margin: "2px 0 0", fontSize: 12, color: "#8892aa" }}>{cat.label} · {ev.questions.length} preguntas</p>
                </div>
                <div style={{ textAlign: "right" }}>
                  <p style={{ margin: 0, fontSize: 16, fontWeight: 700, color: cat.color }}>{completed} / {total}</p>
                  <p style={{ margin: 0, fontSize: 11, color: "#8892aa" }}>{pct}% respondidas</p>
                </div>
              </div>
              <div style={{ marginTop: 8, height: 6, background: "#eef2f8", borderRadius: 3, overflow: "hidden" }}>
                <div style={{ width: `${pct}%`, height: "100%", background: cat.color, transition: "width .3s" }} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ─── USER EVENTS LIST (admin view inside user edit) ────────── */
function UserEventsList({ user, onUpdate, onDelete }) {
  const eventos = (user.eventos || []).slice().sort((a, b) => (b.fecha || "").localeCompare(a.fecha || ""));
  const [editingId, setEditingId] = useState(null);
  const [draftComment, setDraftComment] = useState("");

  if (eventos.length === 0) {
    return (
      <div>
        <Alert type="info">
          Este participante aún no tiene eventos registrados. Para agregar uno, ve a la pestaña <strong>Eventos</strong> en el menú lateral.
        </Alert>
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      {eventos.map(ev => {
        const t = getEventTypeInfo(ev.tipo);
        const isEditing = editingId === ev.id;
        return (
          <div key={ev.id} style={{ border: "1px solid #e2e6f0", borderRadius: 11, padding: "13px 16px", borderLeft: `4px solid ${t.color}`, background: "#fff" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10, flexWrap: "wrap" }}>
              <div style={{ flex: 1, minWidth: 200 }}>
                <p style={{ margin: 0, fontWeight: 700, fontSize: 14, color: "#1a1a2e" }}>
                  {t.icon} {eventDisplayName(ev)}
                </p>
                <p style={{ margin: "3px 0 0", fontSize: 12, color: "#8892aa" }}>
                  📅 {formatEventDate(ev.fecha)}
                  {ev.anio ? ` · ${ev.anio}` : ""}
                </p>
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                {!isEditing && (
                  <>
                    <button onClick={() => { setEditingId(ev.id); setDraftComment(ev.comentarios || ""); }} style={{ ...btnGhost, padding: "5px 11px", fontSize: 12 }}>Editar</button>
                    <button onClick={() => { if (window.confirm("¿Eliminar este registro de evento?")) onDelete(ev.id); }} style={{ ...btnGhost, padding: "5px 11px", fontSize: 12, color: "#c0392b", borderColor: "#f5b8b8" }}>Eliminar</button>
                  </>
                )}
              </div>
            </div>
            {isEditing ? (
              <div style={{ marginTop: 10 }}>
                <textarea value={draftComment} onChange={e => setDraftComment(e.target.value)} rows={3} placeholder="Comentarios sobre la participación..." style={{ ...inputStyle, resize: "vertical" }} />
                <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                  <button onClick={() => { onUpdate(ev.id, { comentarios: draftComment }); setEditingId(null); }} style={{ ...btnPrimary, padding: "7px 16px", fontSize: 13 }}>Guardar comentario</button>
                  <button onClick={() => setEditingId(null)} style={{ ...btnGhost, padding: "7px 16px", fontSize: 13 }}>Cancelar</button>
                </div>
              </div>
            ) : (
              ev.comentarios ? (
                <p style={{ margin: "10px 0 0", fontSize: 13, color: "#4a5a7a", background: "#f5f7fc", padding: "8px 12px", borderRadius: 7, lineHeight: 1.5, whiteSpace: "pre-wrap" }}>
                  💬 {ev.comentarios}
                </p>
              ) : (
                <p style={{ margin: "8px 0 0", fontSize: 12, color: "#b0b8cc", fontStyle: "italic" }}>Sin comentarios</p>
              )
            )}
          </div>
        );
      })}
    </div>
  );
}

/* ─── ADMIN EVENTOS SECTION ─────────────────────────────────── */
function AdminEventosSection({ users, onBulkRegister, onUpdateEvent, onDeleteEvent }) {
  const [view, setView] = useState("registrar");

  // Collect all events with user info
  const allEvents = [];
  for (const u of users) {
    for (const ev of (u.eventos || [])) {
      allEvents.push({ ...ev, userCurp: u.curp, userName: `${u.nombre} ${u.apPat || ""}`.trim() });
    }
  }
  allEvents.sort((a, b) => (b.fecha || "").localeCompare(a.fecha || ""));

  return (
    <div>
      <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
        {[
          { id: "registrar", label: "➕ Registrar evento" },
          { id: "historial", label: `📋 Historial (${allEvents.length})` },
        ].map(t => (
          <button key={t.id} onClick={() => setView(t.id)} style={{
            padding: "9px 18px", borderRadius: 9,
            border: view === t.id ? `2px solid ${SJB}` : "1px solid #d0d5e8",
            background: view === t.id ? SJBG : "#fff",
            color: view === t.id ? SJB : "#6b7a99",
            fontWeight: view === t.id ? 700 : 500,
            fontSize: 13, cursor: "pointer",
          }}>{t.label}</button>
        ))}
      </div>

      {view === "registrar" && <RegistrarEventoForm users={users} onSave={onBulkRegister} />}
      {view === "historial" && <HistorialEventos events={allEvents} onUpdate={onUpdateEvent} onDelete={onDeleteEvent} />}
    </div>
  );
}

/* ─── REGISTRAR EVENTO FORM ─────────────────────────────────── */
function RegistrarEventoForm({ users, onSave }) {
  const today = new Date().toISOString().slice(0, 10);
  const [tipo, setTipo] = useState("");
  const [nombreCustom, setNombreCustom] = useState("");
  const [fecha, setFecha] = useState(today);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState({}); // { curp: { comentarios: "" } }
  const [err, setErr] = useState("");

  const filteredUsers = search.length >= 2 ? users.filter(u => {
    if (selected[u.curp]) return false;
    const q = search.toLowerCase();
    return u.curp?.toLowerCase().includes(q)
        || u.nombre?.toLowerCase().includes(q)
        || u.apPat?.toLowerCase().includes(q)
        || (u.programa || "").toLowerCase().includes(q);
  }).slice(0, 12) : [];

  function addUser(curp) {
    setSelected(s => ({ ...s, [curp]: { comentarios: "" } }));
    setSearch("");
  }
  function removeUser(curp) {
    setSelected(s => { const ns = { ...s }; delete ns[curp]; return ns; });
  }
  function setComment(curp, comentarios) {
    setSelected(s => ({ ...s, [curp]: { ...s[curp], comentarios } }));
  }

  function handleSave() {
    setErr("");
    if (!tipo) { setErr("Selecciona un tipo de evento."); return; }
    if (tipo === "otro" && !nombreCustom.trim()) { setErr("Especifica el nombre del evento (campo 'Otro')."); return; }
    if (!fecha) { setErr("Indica la fecha del evento."); return; }
    const selectedKeys = Object.keys(selected);
    if (selectedKeys.length === 0) { setErr("Agrega al menos un participante."); return; }

    const anio = new Date(fecha).getFullYear();
    const entries = selectedKeys.map(curp => ({
      curp,
      eventData: {
        id: newEventId(),
        tipo,
        nombreCustom: tipo === "otro" ? nombreCustom.trim() : "",
        fecha,
        anio,
        comentarios: selected[curp].comentarios || "",
        registradoEn: new Date().toISOString(),
      },
    }));

    onSave(entries);
    // Reset
    setTipo(""); setNombreCustom(""); setFecha(today); setSelected({}); setSearch("");
  }

  const selectedList = Object.entries(selected).map(([curp, data]) => {
    const u = users.find(x => x.curp === curp);
    return { curp, user: u, ...data };
  });

  return (
    <div style={card}>
      <h2 style={{ margin: "0 0 6px", fontSize: 17, fontWeight: 700 }}>🎯 Registrar evento</h2>
      <p style={{ margin: "0 0 18px", fontSize: 13, color: "#6b7a99" }}>
        Registra asistencia de uno o varios participantes a un mismo evento. Cada participante puede tener su propio comentario.
      </p>

      <SectionTitle>Información del evento</SectionTitle>
      <Field label="Tipo de evento" required>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))", gap: 8 }}>
          {EVENT_TYPES.map(t => {
            const sel = tipo === t.id;
            return (
              <button key={t.id} type="button" onClick={() => setTipo(t.id)} style={{
                display: "flex", alignItems: "center", gap: 8,
                padding: "10px 12px", borderRadius: 9,
                border: sel ? `2px solid ${t.color}` : "1px solid #d0d5e8",
                background: sel ? `${t.color}15` : "#fff",
                color: sel ? t.color : "#1a1a2e",
                fontSize: 13, fontWeight: sel ? 700 : 500, textAlign: "left",
                cursor: "pointer",
              }}>
                <span style={{ fontSize: 18 }}>{t.icon}</span>
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>
      </Field>

      {tipo === "otro" && (
        <Field label="Nombre del evento" required>
          <input value={nombreCustom} onChange={e => setNombreCustom(e.target.value)} placeholder="Ej: Taller de oración, Posada, etc." style={inputStyle} />
        </Field>
      )}

      <Field label="Fecha del evento" required>
        <input type="date" value={fecha} onChange={e => setFecha(e.target.value)} style={{ ...inputStyle, maxWidth: 220 }} />
      </Field>

      <SectionTitle>Participantes ({selectedList.length})</SectionTitle>

      <Field label="Buscar y agregar participantes">
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Escribe nombre, apellido, CURP o programa…"
          style={inputStyle}
        />
        {search.length > 0 && search.length < 2 && (
          <p style={{ fontSize: 12, color: "#8892aa", marginTop: 5 }}>Escribe al menos 2 caracteres…</p>
        )}
        {search.length >= 2 && filteredUsers.length === 0 && (
          <p style={{ fontSize: 12, color: "#8892aa", marginTop: 5 }}>Sin coincidencias.</p>
        )}
        {filteredUsers.length > 0 && (
          <div style={{ marginTop: 8, border: "1px solid #e2e6f0", borderRadius: 10, maxHeight: 280, overflowY: "auto" }}>
            {filteredUsers.map((u, i) => (
              <button key={u.curp} type="button" onClick={() => addUser(u.curp)} style={{
                display: "flex", alignItems: "center", gap: 10, width: "100%",
                padding: "9px 12px", border: "none",
                borderBottom: i < filteredUsers.length - 1 ? "1px solid #f0f2f8" : "none",
                background: "#fff", textAlign: "left", cursor: "pointer", fontSize: 13,
              }}
              onMouseEnter={e => e.currentTarget.style.background = SJBG}
              onMouseLeave={e => e.currentTarget.style.background = "#fff"}>
                <div style={{ width: 30, height: 30, borderRadius: "50%", background: SJBG, color: SJB, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 12, flexShrink: 0 }}>{(u.nombre || "?")[0]?.toUpperCase()}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ margin: 0, fontWeight: 600, color: "#1a1a2e", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{u.nombre} {u.apPat} {u.apMat || ""}</p>
                  <p style={{ margin: 0, fontSize: 11, color: "#8892aa" }}>{u.curp} · {u.programa || "—"}</p>
                </div>
                <span style={{ color: SJB, fontWeight: 700, fontSize: 18 }}>+</span>
              </button>
            ))}
          </div>
        )}
      </Field>

      {selectedList.length > 0 && (
        <div style={{ marginTop: 12, background: "#fafcff", border: "1px solid #d8e3f5", borderRadius: 10, padding: "12px 14px" }}>
          <p style={{ margin: "0 0 10px", fontSize: 13, color: SJBD, fontWeight: 600 }}>
            ✓ {selectedList.length} participante{selectedList.length === 1 ? "" : "s"} seleccionado{selectedList.length === 1 ? "" : "s"}
          </p>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {selectedList.map(s => (
              <div key={s.curp} style={{ background: "#fff", border: "1px solid #e2e6f0", borderRadius: 9, padding: "10px 12px" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 7, gap: 8 }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ margin: 0, fontWeight: 600, fontSize: 13, color: "#1a1a2e", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.user?.nombre} {s.user?.apPat}</p>
                    <p style={{ margin: 0, fontSize: 11, color: "#8892aa" }}>{s.curp}</p>
                  </div>
                  <button type="button" onClick={() => removeUser(s.curp)} style={{ background: "transparent", border: "none", color: "#c0392b", fontSize: 16, cursor: "pointer", padding: "2px 6px" }} title="Quitar">✕</button>
                </div>
                <textarea
                  value={s.comentarios}
                  onChange={e => setComment(s.curp, e.target.value)}
                  placeholder="Comentarios sobre la participación (opcional)..."
                  rows={2}
                  style={{ ...inputStyle, fontSize: 13, resize: "vertical", minHeight: 50 }}
                />
              </div>
            ))}
          </div>
        </div>
      )}

      {err && <Alert type="error">{err}</Alert>}

      <div style={{ marginTop: 20, display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
        <button onClick={handleSave} style={btnPrimary}>
          Guardar evento {selectedList.length > 0 ? `(${selectedList.length})` : ""}
        </button>
        {selectedList.length > 0 && (
          <button onClick={() => setSelected({})} style={btnGhost}>Limpiar participantes</button>
        )}
      </div>
    </div>
  );
}

/* ─── HISTORIAL DE EVENTOS ──────────────────────────────────── */
function HistorialEventos({ events, onUpdate, onDelete }) {
  const [filterTipo, setFilterTipo] = useState("");
  const [filterAnio, setFilterAnio] = useState("");
  const [search, setSearch] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [draftComment, setDraftComment] = useState("");

  const anios = [...new Set(events.map(e => e.anio).filter(Boolean))].sort().reverse();

  const filtered = events.filter(e => {
    if (filterTipo && e.tipo !== filterTipo) return false;
    if (filterAnio && String(e.anio) !== String(filterAnio)) return false;
    if (search) {
      const q = search.toLowerCase();
      const matches = e.userName?.toLowerCase().includes(q)
        || e.userCurp?.toLowerCase().includes(q)
        || (e.nombreCustom || "").toLowerCase().includes(q)
        || (e.comentarios || "").toLowerCase().includes(q);
      if (!matches) return false;
    }
    return true;
  });

  // Group by event signature: tipo + fecha + nombreCustom
  const groups = {};
  for (const e of filtered) {
    const key = `${e.tipo}|${e.fecha}|${e.nombreCustom || ""}`;
    if (!groups[key]) groups[key] = { tipo: e.tipo, fecha: e.fecha, nombreCustom: e.nombreCustom, anio: e.anio, entries: [] };
    groups[key].entries.push(e);
  }
  const groupList = Object.values(groups).sort((a, b) => (b.fecha || "").localeCompare(a.fecha || ""));

  return (
    <div style={card}>
      <h2 style={{ margin: "0 0 14px", fontSize: 17, fontWeight: 700 }}>📋 Historial de eventos</h2>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 10, marginBottom: 16 }}>
        <select value={filterTipo} onChange={e => setFilterTipo(e.target.value)} style={selStyle}>
          <option value="">Todos los tipos</option>
          {EVENT_TYPES.map(t => <option key={t.id} value={t.id}>{t.icon} {t.label}</option>)}
        </select>
        <select value={filterAnio} onChange={e => setFilterAnio(e.target.value)} style={selStyle}>
          <option value="">Todos los años</option>
          {anios.map(y => <option key={y} value={y}>{y}</option>)}
        </select>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por nombre, CURP, comentario…" style={inputStyle} />
      </div>

      <p style={{ fontSize: 12, color: "#8892aa", marginBottom: 12 }}>
        {filtered.length} registro{filtered.length === 1 ? "" : "s"} · {groupList.length} evento{groupList.length === 1 ? "" : "s"} único{groupList.length === 1 ? "" : "s"}
      </p>

      {groupList.length === 0 && (
        <Alert type="info">No hay eventos que coincidan con los filtros.</Alert>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        {groupList.map((g, gi) => {
          const t = getEventTypeInfo(g.tipo);
          const groupName = g.tipo === "otro" ? (g.nombreCustom || "Otro evento") : t.label;
          return (
            <div key={gi} style={{ border: "1px solid #e2e6f0", borderRadius: 12, overflow: "hidden", borderLeft: `4px solid ${t.color}` }}>
              <div style={{ background: `${t.color}10`, padding: "12px 16px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
                <div>
                  <p style={{ margin: 0, fontWeight: 700, fontSize: 14, color: "#1a1a2e" }}>{t.icon} {groupName}</p>
                  <p style={{ margin: "2px 0 0", fontSize: 12, color: "#5a6a8a" }}>📅 {formatEventDate(g.fecha)} · {g.entries.length} participante{g.entries.length === 1 ? "" : "s"}</p>
                </div>
              </div>
              <div>
                {g.entries.map((e, ei) => {
                  const isEditing = editingId === e.id;
                  return (
                    <div key={e.id} style={{ padding: "11px 16px", borderTop: ei > 0 ? "1px solid #f0f2f8" : "none", background: "#fff" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10, flexWrap: "wrap" }}>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <p style={{ margin: 0, fontWeight: 600, fontSize: 13, color: "#1a1a2e" }}>👤 {e.userName}</p>
                          <p style={{ margin: "2px 0 0", fontSize: 11, color: "#8892aa" }}>{e.userCurp}</p>
                        </div>
                        {!isEditing && (
                          <div style={{ display: "flex", gap: 5 }}>
                            <button onClick={() => { setEditingId(e.id); setDraftComment(e.comentarios || ""); }} style={{ ...btnGhost, padding: "4px 10px", fontSize: 12 }}>Editar</button>
                            <button onClick={() => { if (window.confirm("¿Eliminar este registro?")) onDelete(e.userCurp, e.id); }} style={{ ...btnGhost, padding: "4px 10px", fontSize: 12, color: "#c0392b", borderColor: "#f5b8b8" }}>Eliminar</button>
                          </div>
                        )}
                      </div>
                      {isEditing ? (
                        <div style={{ marginTop: 8 }}>
                          <textarea value={draftComment} onChange={ev => setDraftComment(ev.target.value)} rows={3} placeholder="Comentarios..." style={{ ...inputStyle, resize: "vertical", fontSize: 13 }} />
                          <div style={{ display: "flex", gap: 8, marginTop: 7 }}>
                            <button onClick={() => { onUpdate(e.userCurp, e.id, { comentarios: draftComment }); setEditingId(null); }} style={{ ...btnPrimary, padding: "6px 14px", fontSize: 12 }}>Guardar</button>
                            <button onClick={() => setEditingId(null)} style={{ ...btnGhost, padding: "6px 14px", fontSize: 12 }}>Cancelar</button>
                          </div>
                        </div>
                      ) : (
                        e.comentarios ? (
                          <p style={{ margin: "7px 0 0", fontSize: 13, color: "#4a5a7a", background: "#f5f7fc", padding: "7px 11px", borderRadius: 7, lineHeight: 1.5, whiteSpace: "pre-wrap" }}>💬 {e.comentarios}</p>
                        ) : (
                          <p style={{ margin: "5px 0 0", fontSize: 11, color: "#b0b8cc", fontStyle: "italic" }}>Sin comentarios</p>
                        )
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
