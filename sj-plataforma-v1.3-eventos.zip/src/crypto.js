const SALT = "sj_abp_plataforma_2025";

export async function hashPassword(password) {
  const enc = new TextEncoder();
  const data = enc.encode(SALT + password);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(hashBuffer))
    .map(b => b.toString(16).padStart(2, "0"))
    .join("");
}

export function parseCURP(curp) {
  if (!curp || curp.length < 18) return { dob: "", sex: "" };
  const c = curp.toUpperCase();
  const y = c.slice(4, 6), m = c.slice(6, 8), d = c.slice(8, 10);
  const sc = c[10];
  const year = parseInt(y) > 25 ? "19" + y : "20" + y;
  return {
    dob: `${year}-${m}-${d}`,
    sex: sc === "H" ? "Hombre" : sc === "M" ? "Mujer" : ""
  };
}

export function calcAge(dob) {
  if (!dob) return null;
  const today = new Date(), birth = new Date(dob);
  let age = today.getFullYear() - birth.getFullYear();
  const mo = today.getMonth() - birth.getMonth();
  if (mo < 0 || (mo === 0 && today.getDate() < birth.getDate())) age--;
  return age;
}

export function isMinor(dob) {
  const a = calcAge(dob);
  return a !== null && a < 18;
}
