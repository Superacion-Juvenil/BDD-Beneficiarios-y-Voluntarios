const KEYS = {
  auth: "sj_auth_v1",
  users: "sj_users_v1",
};

export function loadAuth() {
  try { const r = localStorage.getItem(KEYS.auth); return r ? JSON.parse(r) : null; } catch { return null; }
}
export function saveAuth(d) { try { localStorage.setItem(KEYS.auth, JSON.stringify(d)); } catch(e){ console.error(e); } }
export function loadUsers() {
  try { const r = localStorage.getItem(KEYS.users); return r ? JSON.parse(r) : null; } catch { return null; }
}
export function saveUsers(d) { try { localStorage.setItem(KEYS.users, JSON.stringify(d)); } catch(e){ console.error(e); } }
