/* ─────────────────────────────────────────────────────────────────
   EVALUACIONES PRECARGADAS — Superación Juvenil A.B.P.
   Estructura:
     id, title, description, category, applies (filtros), questions
   Categorías: diagnostico | seguimiento | satisfaccion
   Tipos de pregunta:
     - text       : campo corto
     - longtext   : campo extenso (textarea)
     - single     : una sola opción
     - multi      : varias opciones
     - scale      : escala 1-5
   ───────────────────────────────────────────────────────────────── */

export const EVALUACIONES = [
  /* ─── 1. DIAGNÓSTICO INICIAL — todos los beneficiarios ─────── */
  {
    id: "diag-conociendome",
    title: "Conociéndome",
    description: "Cuestionario de diagnóstico inicial. Nos ayuda a conocerte mejor para acompañarte en tu camino.",
    category: "diagnostico",
    applies: { tipo: ["beneficiario"] },
    estimatedMinutes: 10,
    questions: [
      {
        id: "q1",
        type: "text",
        question: "¿Cómo describirías tu carácter en tres palabras?",
        required: true,
      },
      {
        id: "q2",
        type: "multi",
        question: "¿Cuáles consideras tus principales fortalezas? (Selecciona hasta 4)",
        options: ["Empatía", "Liderazgo", "Creatividad", "Disciplina", "Honestidad", "Perseverancia", "Comunicación", "Trabajo en equipo", "Organización", "Resiliencia"],
        maxSelect: 4,
        required: true,
      },
      {
        id: "q3",
        type: "multi",
        question: "¿En qué áreas te gustaría crecer?",
        options: ["Autoconfianza", "Manejo de emociones", "Habilidades sociales", "Vida espiritual", "Hábitos de estudio", "Salud y bienestar", "Liderazgo", "Toma de decisiones", "Comunicación con familia"],
        required: true,
      },
      {
        id: "q4",
        type: "scale",
        question: "Del 1 al 5, ¿qué tan seguro/a te sientes de ti mismo/a?",
        required: true,
      },
      {
        id: "q5",
        type: "single",
        question: "¿Qué valor consideras más importante en tu vida hoy?",
        options: ["Familia", "Fe", "Honestidad", "Servicio a otros", "Estudio/Crecimiento", "Amistad", "Justicia", "Libertad"],
        required: true,
      },
      {
        id: "q6",
        type: "text",
        question: "¿Quién es una persona que admiras y por qué?",
      },
      {
        id: "q7",
        type: "longtext",
        question: "¿Cuál es un sueño grande que tienes para tu vida?",
      },
      {
        id: "q8",
        type: "multi",
        question: "¿Qué actividades disfrutas más en tu tiempo libre?",
        options: ["Leer", "Deporte", "Música", "Arte/Dibujo", "Videojuegos", "Salir con amigos", "Voluntariado", "Cine/Series", "Cocinar", "Estar en familia"],
      },
      {
        id: "q9",
        type: "longtext",
        question: "Si pudieras cambiar algo en el mundo, ¿qué sería?",
      },
    ],
  },

  /* ─── 2. SEGUIMIENTO TRIMESTRAL — beneficiarios ─────────────── */
  {
    id: "seg-trimestral",
    title: "Seguimiento trimestral",
    description: "Evaluación de tu avance en el último trimestre. Tu honestidad nos ayuda a apoyarte mejor.",
    category: "seguimiento",
    applies: { tipo: ["beneficiario"] },
    estimatedMinutes: 7,
    questions: [
      {
        id: "q1",
        type: "scale",
        question: "¿Qué tanto cumpliste con las metas que te propusiste este trimestre? (1 = nada, 5 = totalmente)",
        required: true,
      },
      {
        id: "q2",
        type: "scale",
        question: "¿Qué tan constante fue tu asistencia a las actividades del programa?",
        required: true,
      },
      {
        id: "q3",
        type: "scale",
        question: "¿Qué tanto participaste activamente en las dinámicas y reuniones?",
        required: true,
      },
      {
        id: "q4",
        type: "longtext",
        question: "¿En qué sientes que creciste más como persona este trimestre?",
        required: true,
      },
      {
        id: "q5",
        type: "longtext",
        question: "¿Cuál fue el mayor reto que enfrentaste y cómo lo manejaste?",
      },
      {
        id: "q6",
        type: "longtext",
        question: "¿En qué área necesitas más apoyo del programa o de tu coordinador?",
      },
      {
        id: "q7",
        type: "text",
        question: "Una meta concreta para el próximo trimestre:",
        required: true,
      },
    ],
  },

  /* ─── 3. SATISFACCIÓN — todos ──────────────────────────────── */
  {
    id: "sat-semestral",
    title: "Encuesta de satisfacción",
    description: "Tu retroalimentación es anónima ante tus compañeros y nos ayuda a mejorar.",
    category: "satisfaccion",
    applies: {}, // todos
    estimatedMinutes: 5,
    questions: [
      { id: "q1", type: "scale", question: "Satisfacción general con el programa", required: true },
      { id: "q2", type: "scale", question: "Calidad de las actividades y dinámicas", required: true },
      { id: "q3", type: "scale", question: "Acompañamiento de los coordinadores", required: true },
      { id: "q4", type: "scale", question: "Relación con tus compañeros", required: true },
      { id: "q5", type: "scale", question: "Aprendizaje obtenido", required: true },
      { id: "q6", type: "longtext", question: "¿Qué te ha gustado más del programa?" },
      { id: "q7", type: "longtext", question: "¿Qué cambiarías o mejorarías?" },
      {
        id: "q8",
        type: "single",
        question: "¿Recomendarías el programa a otros jóvenes?",
        options: ["Sí, definitivamente", "Probablemente sí", "No estoy seguro/a", "Probablemente no", "No"],
        required: true,
      },
    ],
  },

  /* ─── 4. ESPECÍFICA MJ Prepa ───────────────────────────── */
  {
    id: "mj-vida-adolescente",
    title: "Mi vida adolescente",
    description: "Evaluación específica para participantes de MJ Prepa. Cómo está tu mundo ahora mismo.",
    category: "diagnostico",
    applies: { programa: ["MJ Prepa"] },
    estimatedMinutes: 7,
    questions: [
      { id: "q1", type: "scale", question: "¿Cómo describirías tu relación con tu familia?", required: true },
      { id: "q2", type: "scale", question: "¿Cómo describirías tu relación con tus amigos?", required: true },
      { id: "q3", type: "scale", question: "¿Cómo manejas la presión escolar?", required: true },
      { id: "q4", type: "scale", question: "¿Cómo manejas la presión de tu grupo de amigos?", required: true },
      {
        id: "q5",
        type: "multi",
        question: "¿En cuáles de estas áreas sientes que necesitas más apoyo?",
        options: ["Autoestima", "Decisiones difíciles", "Conflictos familiares", "Bullying", "Vocación", "Manejo de redes sociales", "Estrés/Ansiedad", "Identidad", "Espiritualidad", "Hábitos de estudio"],
      },
      {
        id: "q6",
        type: "single",
        question: "¿Qué tan identificado/a te sientes con los valores del programa?",
        options: ["Mucho", "Bastante", "Más o menos", "Poco", "Nada"],
        required: true,
      },
      {
        id: "q7",
        type: "longtext",
        question: "¿Hay algo importante que te gustaría que tu coordinador supiera sobre ti?",
      },
    ],
  },

  /* ─── 5. ESPECÍFICA MCU / SU — universitarios ──────────────── */
  {
    id: "univ-vocacion",
    title: "Vida universitaria y vocación",
    description: "Cuestionario para participantes de MCU y SU sobre tu camino universitario y vocacional.",
    category: "diagnostico",
    applies: { programa: ["MCU", "SU"] },
    estimatedMinutes: 8,
    questions: [
      { id: "q1", type: "scale", question: "Discernimiento vocacional: ¿qué tan claro tienes tu camino?", required: true },
      { id: "q2", type: "scale", question: "Vida espiritual y de oración", required: true },
      { id: "q3", type: "scale", question: "Vida académica y desempeño escolar", required: true },
      { id: "q4", type: "scale", question: "Compromiso con el servicio a otros", required: true },
      {
        id: "q5",
        type: "multi",
        question: "¿En qué áreas de liderazgo te ves desarrollándote?",
        options: ["Liderazgo en equipo", "Liderazgo espiritual", "Liderazgo académico", "Emprendimiento social", "Liderazgo comunitario", "Coordinación de grupos", "Mentoría a más jóvenes"],
      },
      {
        id: "q6",
        type: "longtext",
        question: "¿Cuál sientes que es tu misión personal en este momento de tu vida?",
      },
      {
        id: "q7",
        type: "longtext",
        question: "¿En qué área te gustaría recibir más formación?",
      },
    ],
  },

  /* ─── 6. VOLUNTARIOS — servicio ────────────────────────────── */
  {
    id: "vol-servicio",
    title: "Evaluación del servicio voluntario",
    description: "Como colaborador/voluntario, esta evaluación nos ayuda a mejorar tu experiencia y formación.",
    category: "seguimiento",
    applies: { tipo: ["voluntario"] },
    estimatedMinutes: 8,
    questions: [
      { id: "q1", type: "scale", question: "Satisfacción con tu rol actual en SJ A.B.P.", required: true },
      {
        id: "q2",
        type: "single",
        question: "¿Cuántas horas al mes dedicas en promedio a tu servicio?",
        options: ["Menos de 5 horas", "5 a 10 horas", "10 a 20 horas", "Más de 20 horas"],
        required: true,
      },
      { id: "q3", type: "scale", question: "Capacitación recibida para ejercer tu rol", required: true },
      { id: "q4", type: "scale", question: "Apoyo y comunicación con el equipo coordinador", required: true },
      { id: "q5", type: "scale", question: "Impacto que percibes en los jóvenes que acompañas", required: true },
      {
        id: "q6",
        type: "multi",
        question: "¿Qué tipo de formación adicional te interesaría recibir?",
        options: ["Acompañamiento juvenil", "Espiritualidad", "Liderazgo", "Resolución de conflictos", "Salud mental adolescente", "Pedagogía", "Dinámicas de grupo", "Prevención de adicciones"],
      },
      {
        id: "q7",
        type: "single",
        question: "¿Cuál es tu nivel de compromiso para el siguiente ciclo?",
        options: ["Mantener mi servicio actual", "Aumentar mi participación", "Reducir mi participación", "Pausar temporalmente", "Aún no lo decido"],
        required: true,
      },
      {
        id: "q8",
        type: "longtext",
        question: "Comentarios, sugerencias o necesidades específicas:",
      },
    ],
  },
];

/* Filtra evaluaciones aplicables a un usuario específico */
export function evaluacionesParaUsuario(user) {
  if (!user) return [];
  return EVALUACIONES.filter(e => {
    const a = e.applies || {};
    if (a.tipo && a.tipo.length && !a.tipo.includes(user.tipo || "beneficiario")) return false;
    if (a.programa && a.programa.length && !a.programa.includes(user.programa)) return false;
    return true;
  });
}

export const CATEGORIAS = {
  diagnostico:  { label: "Diagnóstico",   color: "#1A56A4", bg: "#E8F0FB", icon: "🧭" },
  seguimiento:  { label: "Seguimiento",   color: "#1a7a45", bg: "#edfaf3", icon: "📈" },
  satisfaccion: { label: "Satisfacción",  color: "#8a5c00", bg: "#fffbea", icon: "💬" },
};
